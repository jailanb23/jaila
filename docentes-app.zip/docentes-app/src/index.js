import React from 'react';
import ReactDOM from 'react-dom';
import DocentesApp from './components/DocentesApp';

ReactDOM.render(
  <React.StrictMode>
    <DocentesApp />
  </React.StrictMode>,
  document.getElementById('root')
);
