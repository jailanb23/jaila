// DocentesForm.js
import React, { useState } from 'react';

const DocentesForm = ({ agregarDocente }) => {
  const [nombre, setNombre] = useState('');
  const [materia, setMateria] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (nombre.trim() && materia.trim()) {
      agregarDocente({ nombre, materia });
      setNombre('');
      setMateria('');
    }
  };

  return (
    <div>
      <h2>Ingresar Docente</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Nombre"
          value={nombre}
          onChange={(e) => setNombre(e.target.value)}
        />
        <input
          type="text"
          placeholder="Materia"
          value={materia}
          onChange={(e) => setMateria(e.target.value)}
        />
        <button type="submit">Agregar</button>
      </form>
    </div>
  );
};

export default DocentesForm;
