// DocentesSearch.js
import React, { useState } from 'react';

const DocentesSearch = ({ buscarDocente }) => {
  const [busqueda, setBusqueda] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (busqueda.trim()) {
      buscarDocente(busqueda);
      setBusqueda('');
    }
  };

  return (
    <div>
      <h2>Buscar Docente</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Nombre o Materia"
          value={busqueda}
          onChange={(e) => setBusqueda(e.target.value)}
        />
        <button type="submit">Buscar</button>
      </form>
    </div>
  );
};

export default DocentesSearch;
