// DocentesApp.js
import React, { useState } from 'react';
import DocentesList from './DocentesList';
import DocentesForm from './DocentesForm';
import DocentesSearch from './DocentesSearch';

const DocentesApp = () => {
  const [docentes, setDocentes] = useState([]);

  const agregarDocente = (docente) => {
    setDocentes([...docentes, docente]);
  };

  const eliminarDocente = (index) => {
    const nuevosDocentes = docentes.filter((_, i) => i !== index);
    setDocentes(nuevosDocentes);
  };

  const buscarDocente = (busqueda) => {
    const resultados = docentes.filter(
      (docente) =>
        docente.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
        docente.materia.toLowerCase().includes(busqueda.toLowerCase())
    );
    console.log(resultados);
  };

  return (
    <div>
      <h1>App de Docentes</h1>
      <DocentesForm agregarDocente={agregarDocente} />
      <DocentesList docentes={docentes} eliminarDocente={eliminarDocente} />
      <DocentesSearch buscarDocente={buscarDocente} />
    </div>
  );
};

export default DocentesApp;
