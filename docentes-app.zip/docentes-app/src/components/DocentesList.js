// DocentesList.js
import React from 'react';

const DocentesList = ({ docentes, eliminarDocente }) => {
  return (
    <div>
      <h2>Lista de Docentes</h2>
      <ul>
        {docentes.map((docente, index) => (
          <li key={index}>
            {docente.nombre} ({docente.materia})
            <button onClick={() => eliminarDocente(index)}>Eliminar</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default DocentesList;
